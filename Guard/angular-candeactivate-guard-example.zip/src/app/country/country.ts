export class Country { 
	constructor(public countryId:number, public name:string,
            	public capital:string, public currency:string) {
	}
}
    